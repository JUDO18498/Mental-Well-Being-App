package com.example.ashitagoyal.mentalwellbeing;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DepressionResult extends AppCompatActivity implements View.OnClickListener{

    TextView result_title;
    TextView result_desc;
    private EditText editTextEmail;
    private Button sendEmail;
    int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_depression_result);

        result_title = (TextView)findViewById(R.id.result_title_text_view);
        result_desc = (TextView)findViewById(R.id.result_desc_text_view);
        editTextEmail = (EditText)findViewById(R.id.email_edit_text);

        TextView text_view_score_count = (TextView) findViewById(R.id.text_view_score_count);
        Intent intent = getIntent();
        score = intent.getIntExtra("score",0);
        text_view_score_count.setText("Score: " + score + "/" + "27");

        if(score>=0 && score<=9){

            result_title.setText("Minimal depression");
            result_desc.setText("Your result indicates that you have none, or very few symptoms of depression. If you notice that your symptoms" +
                    " aren't improving or get worse you may want to bring them up with a health professional or someone who is supporting you.");

        }
        else if(score>9 && score<=18){

            result_title.setText("Mild depression");
            result_desc.setText("Your result indicates that you may be experiencing some symptoms of mild depression. While your symptoms are not likely" +
                    " having a major impact on your life, it is important to monitor them and you may want to bring them up with a mental health professional or someone supporting you.");

        }
        else if(score>18 && score<=22){

            result_title.setText("Moderate depression");
            result_desc.setText("Your result indicates that you may be experiencing symptoms of moderate depression. Based on your result, living with these symptoms could be causing difficulty managing" +
                    " relationships and even the tasks of everyday life. These results do not mean you have depression, but it is time to start a conversation with a menatal health professional.");

        }
        else{

            result_title.setText("Severe depression");
            result_desc.setText("Your depression that you may be experiencing symptoms of severe deprssion. Seem to be greatly interfering with your relationships and everyday tasks." +
                    " These results do not mean you have depression, but it is time to start a conversation with a menatal health professional.");
        }

        sendEmail = (Button)findViewById(R.id.email_send_button);

        sendEmail.setOnClickListener(this);


    }

    private void sendEmail(){
        String email = editTextEmail.getText().toString().trim();
        String subject = "Your Mental Welbeing Test Screen Results ".trim();
        String message;

        String temp;
        if(score>=0 && score<=9){
            temp = "Your result indicates that you have none, or very few symptoms of depression. If you notice that your symptoms" +
                    " aren't improving or get worse you may want to bring them up with a health professional or someone who is supporting you.";

        }
        else if(score>9 && score<=18){

            temp = "Your result indicates that you may be experiencing some symptoms of mild depression. While your symptoms are not likely" +
                    " having a major impact on your life, it is important to monitor them and you may want to bring them up with a mental health professional or someone supporting you.";

        }
        else if(score>18 && score<=22){

            temp = "Your result indicates that you may be experiencing symptoms of moderate depression. Based on your result, living with these symptoms could be causing difficulty managing" +
                    " relationships and even the tasks of everyday life. These results do not mean you have depression, but it is time to start a conversation with a menatal health professional.";

        }
        else{

            temp = "Your result indicates that you may be experiencing symptoms of severe deprssion. Seem to be greatly interfering with your relationships and everyday tasks." +
                    " These results do not mean you have depression, but it is time to start a conversation with a menatal health professional.";
        }

        message = "YOUR MENTAL WELLBEING SCREENING TEST RESULTS"+'\n'+"YOUR SCORE IS:"+'\n'+"Score: " + score + "/" + "27"+'\n'+temp+"\n"+"This screen is not meant to be a diagnosis, or the elimination of a diagnosis. Only a trained medical or mental health professional can diagnode acurately."
                +"\n"+"If you feel like your feelings, thoughts, or behaviors get worse, screen again";

        //Creating SendMail object
        SendMail sm = new SendMail(this, email, subject, message);

        //Executing sendmail to send email
        sm.execute();
    }

    @Override
    public void onClick(View view) {

        sendEmail();

    }
}
