package com.example.ashitagoyal.mentalwellbeing;

public class Question {

    private String question;

    public Question(){

    }

    public Question(String question) {
        this.question = question;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

}
