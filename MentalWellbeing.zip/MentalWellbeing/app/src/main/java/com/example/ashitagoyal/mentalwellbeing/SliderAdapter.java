package com.example.ashitagoyal.mentalwellbeing;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.zip.Inflater;

public class SliderAdapter  extends PagerAdapter{

    Context context;
    LayoutInflater layoutInflater;

    public int[] image = {R.drawable.i1,R.drawable.i2,R.drawable.i3,R.drawable.i4};
    public String[] title = {"Mental Wellbeing","You are not alone","It's not just you","Help is available"};
    public String[] desc = {"Mental health conditions are real, common, and treatable. And recovery is possible.","The World Health Organization has estimated that between 400 to 500 million people across the planet suffer from depression alone.with many more forms of mental illness.",
            "In any given year, as many as 1 in 5 people experience mental illness in some form.","Wherever you are, you can access help to start feeling better and deal with your thoughts and feelings."};

    public int[] bgcolor = {Color.rgb(255,255,255),Color.rgb(255,255,255),Color.rgb(255,255,255),Color.rgb(255,255,255),};

    public SliderAdapter(Context context){
        this.context=context;
    }

    @Override
    public int getCount() {
        return title.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return (view==object);
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((LinearLayout)object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        layoutInflater = (LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.slide,container,false);

        LinearLayout linearLayout = (LinearLayout)view.findViewById(R.id.ll);
        ImageView imageView = (ImageView)view.findViewById(R.id.slideimage);
        TextView textView1 = (TextView)view.findViewById(R.id.title);
        TextView textView2 = (TextView)view.findViewById(R.id.desc);
        linearLayout.setBackgroundColor(bgcolor[position]);
        imageView.setImageResource(image[position]);
        textView1.setText(title[position]);
        textView2.setText(desc[position]);
        container.addView(view);

        return view;
    }
}
