package com.example.ashitagoyal.mentalwellbeing;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DepressionMain extends AppCompatActivity {

    private Button about_depression_btn;
    private TextView about_depression_txt;
    private Button depression_test_btn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_depression_main);
        about_depression_btn = (Button) findViewById(R.id.about_depression_btn);
        about_depression_txt = (TextView) findViewById(R.id.about_depression_txt);
        depression_test_btn = (Button) findViewById(R.id.test_depression_btn);


        about_depression_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                about_depression_txt.setVisibility(View.VISIBLE);
            }
        });

        depression_test_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(DepressionMain.this, DepressionTest.class);
                startActivity(intent);
            }
        });


    }
}
