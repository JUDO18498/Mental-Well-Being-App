package com.example.ashitagoyal.mentalwellbeing;

public class Config {

    public static final String EMAIL ="ashitagoyal12345@gmail.com";
    public static final String PASSWORD ="24051998";

}
